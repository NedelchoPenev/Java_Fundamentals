import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StringBuilder stringBuilder = new StringBuilder();
        String readLine = scanner.nextLine();

        while (!readLine.equals("end")) {
            stringBuilder.append(readLine);
            readLine = scanner.nextLine();
        }

        String result = stringBuilder.toString().replaceAll("</a>", "[/URL]");
        result = result.replaceAll("<a\\s", "[URL ");

        System.out.println(result);
    }
}
