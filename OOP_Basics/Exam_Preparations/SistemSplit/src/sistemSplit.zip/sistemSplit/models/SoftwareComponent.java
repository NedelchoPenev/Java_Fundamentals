package sistemSplit.models;

public abstract class SoftwareComponent extends Component {


    protected SoftwareComponent(String name, String type) {
        super(name, type);
    }
}
